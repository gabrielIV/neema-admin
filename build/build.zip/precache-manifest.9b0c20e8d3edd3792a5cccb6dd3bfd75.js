self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "df2e4a0488ed1bf741e4ff80dfa67344",
    "url": "/admin/index.html"
  },
  {
    "revision": "2eab6c58a37846f6c750",
    "url": "/admin/static/css/main.49596370.chunk.css"
  },
  {
    "revision": "2519a243700747ecdcbc",
    "url": "/admin/static/js/2.a7a9c629.chunk.js"
  },
  {
    "revision": "2eab6c58a37846f6c750",
    "url": "/admin/static/js/main.9ffcb6c4.chunk.js"
  },
  {
    "revision": "7c4f45329e47798217a3",
    "url": "/admin/static/js/runtime~main.b3695f6e.js"
  },
  {
    "revision": "423332e299a0bf344d7040f218eb050c",
    "url": "/admin/static/media/amana-logo.423332e2.png"
  }
]);